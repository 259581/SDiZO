﻿#include <iostream>
#include <fstream>
#include <string>
#include <chrono>

using namespace std;

#define max_size 1000
const int max_cost = 10;
int parent[max_size];

void usunElement(int graph[max_size][max_size], int instancja);
void czas(std::string nazwa_pliku, float time, int instancja);
void odczyt_pliku(std::string nazwa_pliku, int arr_int[max_size][max_size]);
void jarnik_prima(int graph[max_size][max_size], int size);
void print_graph(int graph[max_size][max_size], int start_row, int end_row, int start_col, int end_col);

int main()
{
    /*
    int values[6][6]={{0,1,0,1,0,2},{1,0,3,2,0,2},{0,3,0,0,0,3},
    {1,2,0,0,4,4},{0,0,0,4,0,4},{2,2,3,4,4,0}};

    auto begin = std::chrono::high_resolution_clock::now();
    jarnik_prima(values, max_size);
    auto end = std::chrono::high_resolution_clock::now();
    auto elapsed = std::chrono::duration_cast<std::chrono::nanoseconds>(end - begin);
    float time_m = 0;
    time_m = elapsed.count() * 1e-9;
    czas("time.csv", time_m, max_size);
    
    long koszt_calkowity = 0;
    cout << "MST:" << endl;
    for (int i = 0; i < max_size; i++) {
        cout << parent[i] + 1 << " - " << i + 1 << " koszt: " << values[i][parent[i]] << endl;
        koszt_calkowity = koszt_calkowity + values[i][parent[i]];
    }
    cout << "SUMA: " << koszt_calkowity << endl;
    //print_graph(values,0,max_size,0,max_size);
    return 0;
    */
   auto values = new int[max_size][max_size];
    odczyt_pliku("matrix.csv", values);
    int krok = 100;
    int instancja = krok;
    while (instancja <= 1000) {
        float time_m = 0;

        for (int i = 0; i < 0.9 * instancja; i++)
        {
            usunElement(values, instancja);
        }

        auto begin = std::chrono::high_resolution_clock::now();

        jarnik_prima(values, instancja);

        auto end = std::chrono::high_resolution_clock::now();
        auto elapsed = std::chrono::duration_cast<std::chrono::nanoseconds>(end - begin);
        time_m = elapsed.count() * 1e-9;

        czas("time.csv", time_m, instancja);
        cout << instancja << endl;
        instancja = instancja + krok;
    }
    // Wyświetlenie minimalnego drzewa spinającego
    long koszt_calkowity = 0;
    cout << "Minimalne drzewo spinajace:" << endl;
    for (int i = 0; i < 1000; i++) {
        //cout << parent[i] + 1 << " - " << i + 1 << " koszt: " << values[i][parent[i]] << endl;
        koszt_calkowity = koszt_calkowity + values[i][parent[i]];
    }
    cout << "Koszt calkowity: " << koszt_calkowity << endl;
}

void jarnik_prima(int graph[max_size][max_size], int size) {
    int cost[max_size];
    bool added[max_size];
    for (int i = 0; i < size; i++) {
        cost[i] = max_cost;
        added[i] = false;
        parent[i] = 0;
    }
    cost[0] = 0;

    // Wyznaczanie minimalnego drzewa spinającego
    for (int i = 0; i < size - 1; i++) {
        // Wyszukanie wierzchołka o najmniejszym koszcie
        int min_cost = max_cost, min_index;
        for (int j = 0; j < size; j++) {
            if (!added[j] && cost[j] < min_cost) {
                min_cost = cost[j];
                min_index = j;
            }
        }
        // Dodanie wierzchołka
        added[min_index] = true;
        // Aktualizacja kosztów i rodziców wierzchołków
        for (int j = 0; j < size; j++) {
            if (graph[min_index][j] && !added[j] && graph[min_index][j] < cost[j]) {
                parent[j] = min_index;
                cost[j] = graph[min_index][j];
            }
        }
    }
}

void odczyt_pliku(std::string nazwa_pliku, int arr_int[max_size][max_size]) {
    std::fstream plik;
    std::string buff;
    plik.open(nazwa_pliku, std::ios::in);
    if (plik.is_open() == true) {
        for (int i = 0; i < max_size; i++) {
            for (int j = 0; j < max_size; j++) {
                getline(plik, buff, ';');
                arr_int[i][j] = std::stoi(buff);
            }

        }
        plik.close();
    }
    else {
        std::cout << "Brak dostępu do pliku z tablicą krawędzi\n";
    }
}

void czas(std::string nazwa_pliku, float time, int instancja) {
    std::fstream plik;
    plik.open(nazwa_pliku, std::ios::app);
    if (plik.is_open() == true) {
        plik << time << ";" << instancja << ";" << "\n";
        plik.close();
    }
    else {
        std::cout << "Nie udało się otworzyć pliku do zapisu\n";
    }
}

void usunElement(int graph[max_size][max_size], int instancja)
{
    srand(time(0));
    int losowyWiersz = rand() % instancja;
    int losowaKolumna = rand() % instancja;
    graph[losowyWiersz][losowaKolumna] = 0;
}

void print_graph(int graph[max_size][max_size], int start_row, int end_row, int start_col, int end_col) {
    printf("Printing graph...\n\n");
    for (int i = start_row; i < end_row; i++) {
        for (int j = start_col; j < end_col; j++) {
            if (i == j) {
                cout << std::setw(3) << "0";
            } else if (graph[i][j] != 0) {
                cout << std::setw(3) << graph[i][j];
            }
        }
        cout << std::endl;
    }
}
