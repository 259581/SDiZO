#include <iostream>

using namespace std;

class BST{
    public:
    int key;
    BST *left, *right;
    
    BST();  //declaration

    BST(int);   //declaration

    BST* Insert(BST*, int);
    BST* Search(BST*, int);
    void InOrder(BST*);
};

BST::BST(){
    key = 0;
    left = 0;
    right = 0;
}

BST::BST(int value){
    key = value;
    left = right = NULL;
}

BST* BST::Insert(BST* root, int value){
    if(!root){
        return new BST(value);
    }

    if(value > root -> key){
        root -> right = Insert(root ->right, value);
    }
    else if(value < root -> key){
        root -> left = Insert(root -> left, value);
    }
    
    return root;
}

void BST::InOrder(BST* root){
    if(!root){
        return;
    }
    InOrder(root -> left);
    cout << root -> key << " ";
    InOrder(root -> right);

}

BST* BST::Search(BST* root, int value){
    if (value< root->key){

    }
}

int main(){
    cout<<"Hello world!"<<endl;
    BST tree, *root(NULL);
    root = tree.Insert(root, 10);
    tree.Insert(root, 30);
    tree.Insert(root, 20);
    tree.Insert(root, 40);
    tree.Insert(root, 70);
    tree.Insert(root, 60);
    tree.Insert(root, 80);

    tree.InOrder(root);
    return 0;
}