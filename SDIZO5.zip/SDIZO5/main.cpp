#include <iostream>
#include <fstream>
#include <chrono>
using namespace std;
#define SIZE 1000   //rozmiar tablicy dynamicznej
#define rp 10   //powtorzenia

class BST{
    public:
    int key;
    BST *left, *right;
    
    BST();  //declaration

    BST(int);   //declaration

    BST* Insert(BST*, int);
    BST* Search(BST*, int);
    void InOrder(BST*);
    BST* Delete(BST*,int);
    void DisplayTree(BST*, int);
};

BST::BST(){
    key = 0;
    left = 0;
    right = 0;
}

BST::BST(int value){
    key = value;
    left = right = NULL;
}

BST* BST::Insert(BST* root, int value)
{
    if (!root) {
        return new BST(value);
    }

    if (value > root->key) {
        root->right = Insert(root->right, value);
    }
    else if (value < root->key) {
        root->left = Insert(root->left, value);
    }

    return root;
}
void BST::DisplayTree(BST* root, int level)
{
    if (root == nullptr) {
        return;
    }

    DisplayTree(root->right, level + 1);

    for (int i = 0; i < level; i++) {
        cout << "||";
    }

    cout << root->key << endl;

    DisplayTree(root->left, level + 1);
}

void BST::InOrder(BST* root){
    if(!root){
        return;
    }
    InOrder(root -> left);
    cout << root -> key << " ";
    InOrder(root -> right);
}

BST* BST::Search(BST* root, int value)
{
    if (root == nullptr || root->key == value) {
        return root;
    }

    if (value < root->key) {
        return Search(root->left, value);
    }
    else {
        return Search(root->right, value);
    }
}

BST* BST::Delete(BST* root, int value)
{
    if (root == nullptr) {
        return root;
    }

    if (value < root->key) {
        root->left = Delete(root->left, value);
    }
    else if (value > root->key) {
        root->right = Delete(root->right, value);
    }
    else {
        if (root->left == nullptr) {
            BST* temp = root->right;
            delete root;
            return temp;
        }
        else if (root->right == nullptr) {
            BST* temp = root->left;
            delete root;
            return temp;
        }

        BST* temp = root->right;
        while (temp && temp->left) {
            temp = temp->left;
        }

        root->key = temp->key;
        root->right = Delete(root->right, temp->key);
    }

    return root;
}

void readNumbers(std::string fileName, int **array, int amount){
    std::fstream file;
    std::string BUFF;
    file.open(fileName, std::ios::in);
    if (file.is_open()){
        for(int i = 0; i<amount; i++){
            for(int j=0; j<amount; j++){
                file >> BUFF;
                array[i][j] = stoi(BUFF);
            }
        }
        file.close();
    }else {
        printf("Something went wrong, couldn't read numbers\n");
        exit(1);
    }
}
void matrixGenerator(int size) {
    FILE* file;
    file = fopen("matrix.txt", "w");
    if (file == NULL) {
        printf("Can't open file to save matrix\n");
        return;
    }

    srand(time(NULL));

    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            int number = rand()%500;
            number = number - (rand() % 500);
            fprintf(file, "%d ", number);
        }
        fprintf(file, "\n");
    }

    fclose(file);
}
int main(){
    BST tree, *root(NULL);
    BST tree2, *root2(NULL);
    matrixGenerator(SIZE);
    
    int **matrix;
    matrix = new int *[SIZE];
    for(int i = 0; i<SIZE; i++){
        matrix[i] = new int[SIZE];
    }

    for(int i = 0; i<SIZE; i++){
        for(int j = 0; j<SIZE; j++){
        matrix[i][j] = 0;
        }
    }
    readNumbers("matrix.txt", matrix, SIZE);
    double time_m = 0;
    double average = 0;
    std::fstream file;
    file.open(".\\results",std::ios::out);
        for (int i=0; i<rp; i++){
            
            auto begin = std::chrono::high_resolution_clock::now();
            for(int i = 0; i<SIZE; i++){
                for(int j=0; j<SIZE; j++){
                    root2 = tree2.Insert(root2, matrix[i][j]);
                }
            }
        auto end = std::chrono::high_resolution_clock::now();
        auto elapsed = std::chrono::duration_cast<std::chrono::nanoseconds>(end - begin);
        time_m = elapsed.count()*1e-6;    // czas zapisywany w milisekundach
        average = average + time_m;
        file << "Operation time [ms]: "<< time_m <<" || Instance Size: "<< SIZE << std::endl;
        }

    average = average/rp;
    cout<<"Srednia czasu tworzenia drzewa: "<<average<<endl;

    file.close();
    printf("\nProgram wykonal operacje tworzenia drzewa BST i zapisal czas wykonania do pliku\n");
    printf("Teraz stworz swoje wlasne drzewo :)\n");
    int number = 0;
    while(1){
        printf("\nMenu:\n");
        printf("1. Wyswietl drzewo BST w kolejnosci rosnacej\n");
        printf("2. Dodaj liczbe do drzewa\n");
        printf("3. Usun liczbe z drzewa\n");
        printf("4. Wyswietl drzewo\n");
        printf("5. Wyszukaj liczbe\n");
        printf("0. Wyjdz\n");
        int decision = 0;
        cin>>decision;
        switch (decision)
        {
        case 1:
            if(root==nullptr){
                printf("Drzewo jest puste\n");
                break;
            }else{
                printf("Wyswietlam drzewo...\n");
                tree.InOrder(root);
            }

            break;
        case 2:
            printf("Podaj liczbe: ");
            cin >> number;
            if(root==nullptr){
                root = tree.Insert(root, number);
            }
            else{
                tree.Insert(root, number);
            }
            break;
        case 3:
            printf("Podaj liczbe: \n");
            cin >> number;
            root = tree.Delete(root, number);

            break;
        case 4:
            if(root==nullptr){
                printf("Drzewo jest puste\n");
                break;
            }else{
                printf("Wyswietlam drzewo...\n");
                tree.DisplayTree(root,0);
            }
            break;
        case 5:
            printf("Podaj liczbe: \n");
            cin >> number;
            cout << (tree.Search(root,number) ? "Znaleziono\n" : "Nie znaleziono\n");
            break;
        case 0:
            exit(0);
            break;
        default:
            printf("Wybrales niedostepna opcje!\n");
            break;
        }
    }
    return 0;
}