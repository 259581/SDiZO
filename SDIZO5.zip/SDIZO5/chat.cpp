#include <iostream>

class Node {
public:
    int data;
    Node* left;
    Node* right;

    Node(int value) {
        data = value;
        left = nullptr;
        right = nullptr;
    }
};

class BinarySearchTree {
private:
    Node* root;

    Node* insertRecursive(Node* current, int value) {
        if (current == nullptr) {
            return new Node(value);
        }

        if (value < current->data) {
            current->left = insertRecursive(current->left, value);
        } else if (value > current->data) {
            current->right = insertRecursive(current->right, value);
        }

        return current;
    }

    Node* searchRecursive(Node* current, int value) {
        if (current == nullptr || current->data == value) {
            return current;
        }

        if (value < current->data) {
            return searchRecursive(current->left, value);
        }

        return searchRecursive(current->right, value);
    }

public:
    BinarySearchTree() {
        root = nullptr;
    }

    void insert(int value) {
        root = insertRecursive(root, value);
    }

    bool search(int value) {
        Node* result = searchRecursive(root, value);
        return result != nullptr;
    }
};

int main() {
    BinarySearchTree bst;

    bst.insert(10);
    bst.insert(5);
    bst.insert(15);
    bst.insert(2);
    bst.insert(7);

    std::cout << "Searching for 10: " << (bst.search(10) ? "Found" : "Not found") << std::endl;
    std::cout << "Searching for 7: " << (bst.search(7) ? "Found" : "Not found") << std::endl;
    std::cout << "Searching for 20: " << (bst.search(20) ? "Found" : "Not found") << std::endl;

    return 0;
}
