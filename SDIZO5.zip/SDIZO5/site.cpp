// Binary Search Tree operations in C++

#include <iostream>
using namespace std;
#define SIZE 3

int** matrixGenerator(int size) {
    srand(time(NULL));
    int **arr;
    arr = new int *[size];
    for(int i = 0; i<size; i++){
      arr[i] = new int[size];
    }
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            int number = (rand() % 500) - (rand() % 500);
            arr[i][j] = number;
        }

    }
  return arr;
}

struct node {
  int key;
  struct node *left, *right;
};

// Create a node
struct node *newNode(int item) {
  struct node *temp = (struct node *)malloc(sizeof(struct node));
  temp->key = item;
  temp->left = temp->right = NULL;
  return temp;
}
void displayTree(node* root, int level)
{
    if (root != NULL) {
    printf("\n");

    displayTree(root->right, level + 1);

    for (int i = 0; i < level; i++) {
        cout << "   ";
    }

    cout << root->key << endl;
    
    displayTree(root->left, level + 1);
    }
}

// Inorder Traversal
void inorder(struct node *root) {
  if (root != NULL) {
    // Traverse left
    inorder(root->left);

    // Traverse root
    cout << root->key << " -> ";

    // Traverse right
    inorder(root->right);
  }
}

// Insert a node
struct node *insert(struct node *node, int key) {
  // Return a new node if the tree is empty
  if (node == NULL)
  {
    return newNode(key);
  }

  // Traverse to the right place and insert the node
  if (key < node->key){
    node->left = insert(node->left, key);
  }else{
    node->right = insert(node->right, key);
  }
  return node;
}

// Find the inorder successor
struct node *minValueNode(struct node *node) {
  struct node *current = node;

  // Find the leftmost leaf
  while (current && current->left != NULL)
    current = current->left;

  return current;
}

// Deleting a node
struct node *deleteNode(struct node *root, int key) {
  // Return if the tree is empty
  if (root == NULL) return root;

  // Find the node to be deleted
  if (key < root->key)
    root->left = deleteNode(root->left, key);
  else if (key > root->key)
    root->right = deleteNode(root->right, key);
  else {
    // If the node is with only one child or no child
    if (root->left == NULL) {
      struct node *temp = root->right;
      free(root);
      return temp;
    } else if (root->right == NULL) {
      struct node *temp = root->left;
      free(root);
      return temp;
    }

    // If the node has two children
    struct node *temp = minValueNode(root->right);

    // Place the inorder successor in position of the node to be deleted
    root->key = temp->key;

    // Delete the inorder successor
    root->right = deleteNode(root->right, temp->key);
  }
  return root;
}

int main() {
  int ** arr = matrixGenerator(SIZE);

  struct node *root = NULL;

  for(int i=0; i<SIZE; i++){
    for(int j=0; j<SIZE; j++){
      root = insert(root,arr[i][j]);
    }
  }
  inorder(root);
  displayTree(root, 0);
  int a = 0;
  cout<<"\nWhat to delete?\n";
  cin>>a;
  printf("\nAfter deleting %d\n",a);
  root = deleteNode(root, a);
  cout << "\nInorder: ";
  inorder(root);
  displayTree(root, 0);
  
}