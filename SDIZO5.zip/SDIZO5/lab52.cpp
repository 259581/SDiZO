﻿#include <iostream>
#include <random>


using namespace std;

class BST {
    int data;
    BST* left, * right;

public:
    BST();

    BST(int);

    BST* Insert(BST*, int);
    BST* Delete(BST*, int);
    BST* Search(BST*, int);

    void Inorder(BST*);

    void displayTree(BST*, int);
};

BST::BST()
    : data(0)
    , left(nullptr)
    , right(nullptr)
{
}

BST::BST(int value)
{
    data = value;
    left = right = nullptr;
}

BST* BST::Insert(BST* root, int value)
{
    if (!root) {
        return new BST(value);
    }

    if (value > root->data) {
        root->right = Insert(root->right, value);
    }
    else if (value < root->data) {
        root->left = Insert(root->left, value);
    }

    return root;
}

BST* BST::Delete(BST* root, int value)
{
    if (root == nullptr) {
        return root;
    }

    if (value < root->data) {
        root->left = Delete(root->left, value);
    }
    else if (value > root->data) {
        root->right = Delete(root->right, value);
    }
    else {
        if (root->left == nullptr) {
            BST* temp = root->right;
            delete root;
            return temp;
        }
        else if (root->right == nullptr) {
            BST* temp = root->left;
            delete root;
            return temp;
        }

        BST* temp = root->right;
        while (temp && temp->left) {
            temp = temp->left;
        }

        root->data = temp->data;
        root->right = Delete(root->right, temp->data);
    }

    return root;
}

BST* BST::Search(BST* root, int value)
{
    if (root == nullptr || root->data == value) {
        return root;
    }

    if (value < root->data) {
        return Search(root->left, value);
    }
    else {
        return Search(root->right, value);
    }
}

void BST::Inorder(BST* root)
{
    if (!root) {
        return;
    }
    Inorder(root->left);
    cout << root->data << " ";
    Inorder(root->right);
}

void BST::displayTree(BST* root, int level)
{
    if (root == nullptr) {
        return;
    }

    displayTree(root->right, level + 1);

    for (int i = 0; i < level; i++) {
        cout << "->";
    }

    cout << root->data << endl;

    displayTree(root->left, level + 1);
}

int main()
{
    BST b, * root = nullptr;

    int m = 10;
    random_device rdn;
    mt19937 generator(rdn());

    int s;

    for (int i = 0; i < m; i++) {
        s = rand()%10;
        root = b.Insert(root, s);
    }


    /*
    b.Insert(root, 90);
    b.Insert(root, 20);
    b.Insert(root, 42);
    b.Insert(root, 10);
    b.Insert(root, 6);
    b.Insert(root, 80);
    */
    cout << "Binary Search Tree:" << endl;
    b.displayTree(root, 0);

    int searchValue;
    cout << "Search for value: ";
    cin >> searchValue;

    BST* searchResult = b.Search(root, searchValue);
    if (searchResult) {
        cout << "Found " << searchValue << " in the tree." << endl;
    }
    else {
        cout << searchValue << " not found in the tree." << endl;
    }

    int deleteValue;
    cout << "Delete value: ";
    cin >> deleteValue;

    root = b.Delete(root, deleteValue);
    cout << "Binary Search Tree after deleting " << deleteValue << ":" << endl;
    b.displayTree(root, 0);



    return 0;
}
