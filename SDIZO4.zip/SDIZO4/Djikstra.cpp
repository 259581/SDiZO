#include <iostream>
#include <fstream>
#include <cmath>
#include <chrono>
using namespace std;
#define SIZE 1000
struct dane {
  int distance;
  int before;
  bool visited;
};

int findMin(int n, dane* tab) { //podaje wierzchołek do ktorego jest najblizej
  int min = -1;
  int mindist = INT_MAX;
  for (int i = 0; i < n; i++) {
    if (!tab[i].visited && tab[i].distance < mindist) {
      min = i;
      mindist = tab[i].distance;
    }
  }
  return min; //funkcja zwroci -1, jezeli wierzcholek bedzie juz miec wartosc 
              //odwiedzony jako true
}

dane* Dijkstra(int **array, int n, int start) {
  dane* tab = new dane[n];
  for (int i = 0; i < n; i++) { //inicjalizacja elementow obiektu
    tab[i].distance = (i == start) ? 0 : INT_MAX;
    tab[i].visited = false;
    tab[i].before = -1;
  }
  int u = findMin(n, tab);

  //cout<<"Wierzcholek startowy: "<<start<<endl;

  while (u != -1) {
    tab[u].visited = true;
    for (int i = 0; i < n; i++) {
      if (array[u][i] > 0 && tab[u].distance + array[u][i] < tab[i].distance) { 
        tab[i].distance = tab[u].distance + array[u][i];
        tab[i].before = u;
      }
    }

    u = findMin(n, tab);
    //cout<<"Nastepny wierzcholek, do ktorego jest najblizej: "<<u<<", droga: "<<tab[u].dystans<<endl;

  }
  return tab;
}

void wypiszdane(int i, dane d) {
  cout << i << "\t\t";
  if (!d.visited) {
    cout << "nieodwiedzony";
  } else {
    if (d.before == -1)
      cout << "brak";
    else cout << d.before;
    cout << "\t" << d.distance;
  }
  cout << endl;
}

void readNumbers(std::string fileName, int **array, int amount){
    std::fstream file;
    std::string BUFF;
    file.open(fileName, std::ios::in);
    if (file.is_open()){
        for(int i = 0; i<amount; i++){
            for(int j=0; j<amount; j++){
                file >> BUFF;
                array[i][j] = stoi(BUFF);
            }
        }
        file.close();
    }else {
        printf("Something went wrong, couldn't read numbers\n");
        exit(1);
    }
}

void matrixGenerator(int size) {
    FILE* file;
    file = fopen("matrix.txt", "w");
    if (file == NULL) {
        printf("Can't open file to save matrix\n");
        return;
    }

    srand(time(NULL));

    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            int number = rand() % 20 + 1;
            fprintf(file, "%d ", number);
        }
        fprintf(file, "\n");
    }

    fclose(file);
}

int main(){
  matrixGenerator(SIZE);
  int **matrix;
  matrix = new int *[SIZE];
  for(int i = 0; i<SIZE; i++){
    matrix[i] = new int[SIZE];
  }

  for(int i = 0; i<SIZE; i++){
    for(int j = 0; j<SIZE; j++){
      matrix[i][j] = 0;
    }
  }
  readNumbers("matrix.txt", matrix, SIZE);
  int instance = 100;
  double time_m = 0;

  std::fstream file;
  file.open(".\\results",std::ios::out);


    
  while(instance<=SIZE){
    for(int i=0; i<10; i++){
    auto begin = std::chrono::high_resolution_clock::now();

    dane* tab = Dijkstra(matrix, instance, 0);

    auto end = std::chrono::high_resolution_clock::now();
    auto elapsed = std::chrono::duration_cast<std::chrono::nanoseconds>(end - begin);
    time_m = elapsed.count()*1e-6;    // czas zapisywany w milisekundach
    file << "Operation time [ms]: "<< time_m <<" || Instance Size: "<< instance << std::endl;
    
  
    }
    //time_m = time_m/10;
    //file << time_m <<endl;
    instance += 100;

    

  } 
  file.close();
   //przykład z kartki
    int **matrix_kartka;
    matrix_kartka = new int *[5];
    for(int i = 0; i<5; i++){
      matrix_kartka[i] = new int[5];
    }

    for(int i = 0; i<5; i++){
      for(int j = 0; j<5; j++){
        matrix_kartka[i][j] = 0;
      }
    }
    readNumbers("matrix_kartka.txt", matrix_kartka, 5);
    dane* arr = Dijkstra(matrix_kartka, 5, 0);
    cout << "Wierzcholek  Poprzednik  Dystans" << endl;
    for (int i = 0; i < 5; i++)
    wypiszdane(i, arr[i]);
  system("pause");
  return 0;
}

