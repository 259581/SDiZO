#include <string>
#include <vector>
#include <thread>
#include <fstream>
#include <time.h>
#include <vector>
#include <iostream>
#include <windows.h>
#include <unistd.h>
#include <chrono>
#include <cmath>

/******** Config instruction ********/
/* index 0 - file with numbers */
/* index 1 - file with modified numbers */
/* index 2 - name of the algorithm */
/* index 3 - file with algorithm's run-time */
/* index 4 - amount of repetitions */
/* index 5 - how many numbers to read */

/******** Declarations ********/
void readConfig(std::string fileName, int rows, std::string *configs);
void readNumbers(std::string fileName, int *array, int amount);
void workingLoop(int repetition, int *array, std::string readFile, std::string saveFile, void (*f)(int*,int), std::vector<int> instance);
int algorithmName(std::string name);
void printingProgress();
void saveModifiedNumbers(std::string fileName, int array[], int amount);
void displayArray(int arr[], int size);
void show_loading_bar();
void bubbleSort(int *array, int instance);
void quickSort(int* array, int size);
void positioningSort(int* array, int size);


int main() {

    std::vector <int> firstInstance = {10,20,30,40,50,75,100,150,200,350,500,750,1000,1500,2000,3000,4000,5000,7500,10000};
    std::vector <int> secondInstance = {12000,15000,17000,20000,30000,40000,50000,75000,100000};
    std::vector <int> thirdInstance = {150000,200000,300000,400000,500000,700000,900000,1000000};

    std::string *configs = new std::string[6];

    readConfig("C:\\Users\\macko\\Desktop\\SDIZO2\\config.txt",6,configs);
    int *array = new int[stoi(configs[5])];
    int choice = algorithmName(configs[2]);
    switch(choice){
        case 1:
            printf("You have chosen bubble-sort\n");
            workingLoop(stoi(configs[4]), array,configs[0], configs[3], bubbleSort, thirdInstance);
            saveModifiedNumbers(configs[1], array, stoi(configs[5]));
            break;

        case 2:
            printf("You have chosen quick-sort\n");
            workingLoop(stoi(configs[4]), array,configs[0], configs[3], quickSort, thirdInstance);
            saveModifiedNumbers(configs[1], array, stoi(configs[5]));
            break;
        case 3:
            printf("You have chosen positioning-sort\n");
            workingLoop(stoi(configs[4]), array,configs[0], configs[3], positioningSort, thirdInstance);
            saveModifiedNumbers(configs[1], array, stoi(configs[5]));
            break;
        default:
            printf("You haven't chosen anything from the list\n");
            exit(1);
    }

    //displayArray(array,10002);    //argumnty to tablica i ilosc wyswietlonych elementow
    delete[] array;
    delete[] configs;
    return 0;
}


/******** Definitions ********/
void readConfig(std::string fileName, int rows, std::string *configs){
    std::fstream file;
    file.open(fileName, std::ios::in);
    if(file.is_open()){
        for(int i = 0; i<rows; i++){
            getline(file, configs[i]);
        }
    } else {
        printf("Something went wrong, couldn't read config\n");
        exit(1);
    }
    file.close();
}
void readNumbers(std::string fileName, int *array, int amount){
    std::fstream file;
    std::string BUFF;
    file.open(fileName, std::ios::in);
    if (file.is_open()){
        for(int i = 0; i<amount; i++){
            file >> BUFF;
            array[i] = stoi(BUFF);
        }
        file.close();
    }else {
        printf("Something went wrong, couldn't read numbers\n");
    }
}
void workingLoop(int repetition, int *array, std::string readFile, std::string saveFile, void (*f)(int*,int), std::vector<int> instance){
    std::string progress_bar;
    double percentage = 0;
    double time = 0.0;
    int size = instance.size();
    double average = 0.0;
    double progress_level = 100/double(repetition*size);
    std::fstream file;
    file.open(saveFile,std::ios::out);
    if (file.is_open()){
    for(int i=0; i<size; i++){
        for(int j=0; j<repetition; j++){
            readNumbers(readFile, array, instance[i]);
            clock_t start = clock();
            f(array, instance[i]);
            clock_t end = clock();
            time = double(end - start);
            time = (time/CLOCKS_PER_SEC);
            file << time << std::endl;
            average += time;
            percentage += progress_level;
            progress_bar.insert(0,1, '#');
            std::cout << "\r [" << std::floor(percentage) << '%' << "] " << progress_bar;
        }
        average = average/repetition;
        file << average << "\t" << instance[i] << "\t" << "average time|instance size" << std::endl;
        average = 0;
                  
    }
    }else {
        printf("Something went wrong, couldn't open save-file for elapsed time\n");
        exit(2);
    }
    std::cout << "\n\n";
    file.close();

}
int algorithmName(std::string name){
    if(name == "bubblesort"){
        return 1;
    }else if(name == "quicksort") {
        return 2;
    }else if(name == "positioning"){
        return 3;
    }else{
        return 0;
    }
}
void printingProgress(){
    using namespace std::chrono_literals;
        //std::this_thread::sleep_for(100ms);
        //sleep(.1);
        std::cout << "\b\\" << std::flush;
        //std::this_thread::sleep_for(100ms);
        //sleep(.1);
        std::cout << "\b|" << std::flush;
        //std::this_thread::sleep_for(100ms);
        //sleep(.1);
        std::cout << "\b/" << std::flush;
        //std::this_thread::sleep_for(100ms);
        //sleep(.1);
        std::cout << "\b-" << std::flush;
        //std::this_thread::sleep_for(100ms);

}
void saveModifiedNumbers(std::string fileName, int array[], int amount){
    std::fstream file;
    file.open(fileName, std::ios::out);
    if (file.is_open()){
        for(int i = 0; i<amount; i++){
            file << array[i] << ',';
        }
        file.close();
    }else {
        printf("Something went wrong, couldn't open save-file for modified numbers\n");
    }
}
void displayArray(int arr[], int size){
    for (int i=0; i < size-1; i++)
        std::cout<<arr[i]<<"\n";

}
void bubbleSort(int *array, int instance){
    int buff = 0;
    for (int i = 0; i < instance+1; i++) {
        for (int j = 1; j < instance; j++) {
            if (array[j - 1] > array[j]) {
                buff = 0;
                buff = array[j - 1];
                array[j - 1] = array[j];
                array[j] = buff;
            }
        }
        //printf("\e[1;1H\e[2J"); /* for clearing console */
    }
}
void quickSort(int* array, int size) {
    if (size <= 1) {
        return;
    }
    int i = 0, j = size - 1;
    int contain = 0;
    int pivot = array[(0 + size - 1) / 2];
    while (i <= j) {
        while (array[i] < pivot)
            i++;
        while (array[j] > pivot)
            j--;
        if (i <= j) {
            contain = array[i];
            array[i] = array[j];
            array[j] = contain;
            i++;
            j--;
        }
    }
    quickSort(array, j + 1);
    quickSort(array + i, size - i);
}
void positioningSort(int* array, int size) {
    int max = array[0];
    int min = array[0];
    for (int i = 1; i < size; i++) {
        if (array[i] > max) {
            max = array[i];
        }
        if (array[i] < min) {
            min = array[i];
        }
    }
    int* output = (int*)malloc(size * sizeof(int));
    int* count = (int*)calloc(10, sizeof(int));
    for (int exp = 1; (max - min) / exp > 0; exp *= 10) {
        for (int i = 0; i < size; i++) {
            int digit = (array[i] - min) / exp % 10;
            count[digit]++;
        }
        for (int i = 1; i < 10; i++) {
            count[i] += count[i - 1];
        }
        for (int i = size - 1; i >= 0; i--) {
            int digit = (array[i] - min) / exp % 10;
            output[count[digit] - 1] = array[i];
            count[digit]--;
        }
        for (int i = 0; i < size; i++) {
            array[i] = output[i];
        }
        for (int i = 0; i < 10; i++) {
            count[i] = 0;
        }
    }
    free(output);
    free(count);
}