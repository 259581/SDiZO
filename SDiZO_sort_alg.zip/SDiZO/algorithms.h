//
// Created by Maciej Rudy on 16/03/2023.
//

#ifndef SDIZO_ALGORITHMS_H
#define SDIZO_ALGORITHMS_H
void bubbleSort(int*, int);
void quickSort(int*, int);
void positioningSort(int*, int);
#endif //SDIZO_ALGORITHMS_H
