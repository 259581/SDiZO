#include <iostream>


void badCharHeuristic( std::string& str, int size, int* badchar){
    for (int i = 0; i < 256; i++)
        badchar[i] = -1;

    for (int i = 0; i < size; i++)
        badchar[(int) str[i]] = i;
}

void search( std::string& txt,  std::string& pat) {
    int m = pat.size();
    int n = txt.size();

    int badchar[256];

    badCharHeuristic(pat, m, badchar);

    int s = 0;  
    while(s <= (n - m)) {
        int j = m - 1;

        while(j >= 0 && pat[j] == txt[s + j])
            j--;

        if (j < 0) {
            std::cout << "Pattern wystepuje na pozycji: " << s << std::endl;
            if(s + m < n){
                s += m - badchar[txt[s + m]];
            }else{
                s += 1;
            }
        }
        else
            s += std::max(1, j - badchar[txt[s + j]]);
            printf("%d - s z tego maxa\n", s);
    }
}

int main() {
    std::string txt = "skjfkjdupasdfks";
    std::string pat = "dupa";
    search(txt, pat);
    return 0;
}