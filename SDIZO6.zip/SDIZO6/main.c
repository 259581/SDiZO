#include <stdio.h>
void szukaj(int rozmiar_tekstu, int rozmiar_wzorca, char* wzorzec, char* tekst);

int main(){
    char* tekst = "tupalakduparaturhdupaagfhydupafb";
    int rozmiar_tekstu = 30;

    char* wzorzec;
    printf("Podaj wzorzec: ");
    scanf("%s",wzorzec);
    
    int rozmiar_wzorca = 0;
    printf("Ile znakow posiada wzorzec? Podaj liczbę:");
    scanf("%d", &rozmiar_wzorca);

    printf("Wybrany wzorzec: %s\n", wzorzec);
    printf("Rozmiar wzorca: %d\n", rozmiar_wzorca);
    printf("*********************************\n");

    szukaj(rozmiar_tekstu, rozmiar_wzorca, wzorzec, tekst);

    return 0;
}

void szukaj(int rozmiar_tekstu, int rozmiar_wzorca, char* wzorzec, char* tekst){
    int i = 0;
    while(i <= rozmiar_tekstu){
        int k = rozmiar_wzorca - 1;
        while(wzorzec[k] == tekst[i + k]){
            k = k - 1;
        }
        if(k < 0){
            printf("Miejsce znalezienia wzorca: %d\n", i);
            i = i + rozmiar_wzorca;
        }else{
            i = i + 1;
        }
    }
}