#include <stdlib.h>
#include <stdio.h>
#define BUFF_SIZE 1024
int main(){
    char *tekst;
    FILE *f = fopen("tekst.txt", "r");
    fgets(tekst, BUFF_SIZE, f);
    printf("String read: %s\n", tekst);
    fclose(f);
    printf("Tekst:\n");
    printf("%s\n",tekst);
    char* wzorzec;
    printf("Podaj wzorzec: ");
    scanf("%s",wzorzec);
    
    int rozmiar_wzorca = 0;
    printf("Ile znakow posiada wzorzec? Podaj liczbę:");
    scanf("%d", &rozmiar_wzorca);

    printf("Wybrany wzorzec: %s\n", wzorzec);
    printf("Rozmiar wzorca: %d\n", rozmiar_wzorca);
    printf("*********************************\n");

    int *asci;
    asci = (int*)malloc(256 * sizeof(int));
    
    for(int i = 0; i<256; i++){
        asci[i] = 0;
    }
  
    for(int i = 0; i<rozmiar_wzorca; i++){  //wszystkie znaki wystepujace we wzorc
        asci[(int)wzorzec[i]] = 1;
    }
    int rozmiar_tekstu = BUFF_SIZE;
    int i = 0;
    while(i <= rozmiar_tekstu){
        int k = rozmiar_wzorca - 1;
        while(wzorzec[k] == tekst[i + k]){
            k = k - 1;
            //printf("k --\n");
        }
        if(k < 0){
            printf("Miejsce znalezienia wzorca: %d\n", i);
            i = i + rozmiar_wzorca;
        }else{
            i = i + 1;
        }
    }

    return 0;
}

/*
 int *asci;
    asci = (int*)malloc(256 * sizeof(int));
    
    for(int i = 0; i<256; i++){
        asci[i] = 0;
    }
  
    for(int i = 0; i<rozmiar_wzorca; i++){  //wszystkie znaki wystepujace we wzorc
        asci[(int)wzorzec[i]] = 1;
    }
    */